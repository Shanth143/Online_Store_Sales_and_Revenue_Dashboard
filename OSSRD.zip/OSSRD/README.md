# Olist Sales & Revenue Dashboard

A no-build, browser-based dashboard for exploring revenue by month, product category, and Brazilian customer state.

## Run it

Open `index.html` in a modern browser. The dashboard starts with clearly labeled illustrative sample data; it does not pretend those sample values are Olist transactions.

To explore the actual data, download the **Brazilian E-Commerce Public Dataset by Olist** from Kaggle and choose all four CSVs together with **Import CSVs**:

- `olist_orders_dataset.csv`
- `olist_order_items_dataset.csv`
- `olist_products_dataset.csv`
- `olist_customers_dataset.csv`

The optional `product_category_name_translation.csv` translates category labels into English. The dashboard reads and processes CSVs locally in your browser; the files are not uploaded to a server. Required field names must match the standard Olist exports.

## Dashboard definitions

- **Revenue** adds `price` for each order item. Turn on **Include freight** to add `freight_value`.
- **Orders** counts unique orders that have at least one included item.
- **Average order value** is the selected revenue divided by unique orders.
- Orders with `canceled` or `unavailable` status are excluded; other statuses with a valid purchase timestamp are included.
- The date filter uses the order purchase month. Product performance is grouped by product category because the standard products file does not contain human-readable product names.

## Source and dataset terms

Source: [Brazilian E-Commerce Public Dataset by Olist on Kaggle](https://www.kaggle.com/datasets/olistbr/brazilian-ecommerce). The Kaggle listing identifies the license as **CC BY-NC-SA 4.0** and lists the dataset as last modified **October 1, 2021**. The download is free but requires a Kaggle account. Review the [dataset page](https://www.kaggle.com/datasets/olistbr/brazilian-ecommerce) and [license terms](https://creativecommons.org/licenses/by-nc-sa/4.0/) before redistributing data or using it commercially; the license is non-commercial.
