"use strict";

const brl = new Intl.NumberFormat("pt-BR", {
  style: "currency",
  currency: "BRL",
  maximumFractionDigits: 0
});
const compactBrl = new Intl.NumberFormat("pt-BR", {
  style: "currency",
  currency: "BRL",
  notation: "compact",
  maximumFractionDigits: 1
});
const integer = new Intl.NumberFormat("pt-BR");
const monthFormat = new Intl.DateTimeFormat("en", { month: "short", year: "2-digit", timeZone: "UTC" });
const requiredColumns = {
  orders: ["order_id", "customer_id", "order_status", "order_purchase_timestamp"],
  order_items: ["order_id", "product_id", "price", "freight_value"],
  products: ["product_id", "product_category_name"],
  customers: ["customer_id", "customer_state"]
};

const sampleData = createSampleData();
let activeData = sampleData;
let toastTimer;

const elements = {
  badge: document.getElementById("data-badge"),
  date: document.getElementById("date-filter"),
  state: document.getElementById("state-filter"),
  category: document.getElementById("category-filter"),
  freight: document.getElementById("freight-toggle"),
  upload: document.getElementById("csv-upload"),
  toast: document.getElementById("toast")
};

function createSampleData() {
  const rows = [
    ["2017-01-15", "SP", "health_beauty", "129.9", "16.2"],
    ["2017-01-23", "RJ", "watches_gifts", "249.0", "12.5"],
    ["2017-02-04", "MG", "bed_bath_table", "89.9", "18.4"],
    ["2017-02-17", "SP", "computers_accessories", "399.0", "14.8"],
    ["2017-03-08", "PR", "sports_leisure", "149.5", "20.1"],
    ["2017-03-22", "SP", "health_beauty", "219.0", "12.8"],
    ["2017-04-03", "BA", "housewares", "79.9", "24.0"],
    ["2017-04-19", "RJ", "watches_gifts", "319.0", "11.6"],
    ["2017-05-06", "SP", "bed_bath_table", "119.9", "16.4"],
    ["2017-05-25", "SC", "computers_accessories", "559.0", "19.2"],
    ["2017-06-11", "MG", "health_beauty", "159.0", "13.3"],
    ["2017-06-28", "SP", "sports_leisure", "199.9", "17.0"],
    ["2017-07-07", "DF", "housewares", "99.0", "21.4"],
    ["2017-08-16", "SP", "watches_gifts", "429.0", "14.5"],
    ["2017-09-10", "RS", "bed_bath_table", "139.9", "15.8"],
    ["2017-10-21", "RJ", "health_beauty", "189.0", "12.1"],
    ["2017-11-09", "SP", "computers_accessories", "679.0", "17.5"],
    ["2017-11-24", "MG", "watches_gifts", "289.0", "11.8"],
    ["2017-12-05", "BA", "sports_leisure", "229.0", "23.1"],
    ["2017-12-19", "SP", "housewares", "109.9", "16.7"],
    ["2018-01-12", "PR", "health_beauty", "179.0", "14.0"],
    ["2018-02-03", "SP", "bed_bath_table", "199.0", "18.9"],
    ["2018-03-14", "RJ", "computers_accessories", "499.0", "15.2"],
    ["2018-04-23", "SC", "watches_gifts", "359.0", "12.7"],
    ["2018-05-17", "SP", "sports_leisure", "269.0", "20.5"],
    ["2018-06-02", "MG", "health_beauty", "199.9", "13.6"],
    ["2018-07-20", "DF", "housewares", "149.0", "22.3"],
    ["2018-08-08", "SP", "computers_accessories", "749.0", "19.8"],
    ["2018-09-16", "RS", "bed_bath_table", "169.0", "16.1"],
    ["2018-10-29", "BA", "watches_gifts", "399.0", "14.6"]
  ];

  const orders = [];
  const items = [];
  const customers = [];
  const products = [];
  const customerIds = new Set();
  const productIds = new Set();

  rows.forEach((row, index) => {
    const [date, state, category, price, freight] = row;
    const orderId = `demo-order-${index + 1}`;
    const customerId = `demo-customer-${index + 1}`;
    const productId = `demo-product-${category}`;
    orders.push({
      order_id: orderId,
      customer_id: customerId,
      order_status: "delivered",
      order_purchase_timestamp: `${date} 12:00:00`
    });
    items.push({ order_id: orderId, product_id: productId, price, freight_value: freight });
    if (!customerIds.has(customerId)) {
      customers.push({ customer_id: customerId, customer_state: state });
      customerIds.add(customerId);
    }
    if (!productIds.has(productId)) {
      products.push({ product_id: productId, product_category_name: category });
      productIds.add(productId);
    }
  });
  return { orders, items, products, customers, translations: [] };
}

function parseCsv(text) {
  const rows = [];
  let row = [];
  let field = "";
  let quoted = false;
  const source = text.replace(/^\uFEFF/, "");

  for (let index = 0; index < source.length; index += 1) {
    const character = source[index];
    if (quoted) {
      if (character === '"' && source[index + 1] === '"') {
        field += '"';
        index += 1;
      } else if (character === '"') {
        quoted = false;
      } else {
        field += character;
      }
    } else if (character === '"' && field.length === 0) {
      quoted = true;
    } else if (character === ",") {
      row.push(field);
      field = "";
    } else if (character === "\n" || character === "\r") {
      if (character === "\r" && source[index + 1] === "\n") index += 1;
      row.push(field);
      field = "";
      if (row.some((value) => value !== "")) rows.push(row);
      row = [];
    } else {
      field += character;
    }
  }
  if (field.length || row.length) {
    row.push(field);
    if (row.some((value) => value !== "")) rows.push(row);
  }

  const headers = rows.shift();
  if (!headers || headers.length < 2) throw new Error("The file does not look like a CSV with a header row.");
  const normalizedHeaders = headers.map((header) => header.trim().toLowerCase());
  return rows.map((values) => Object.fromEntries(
    normalizedHeaders.map((header, index) => [header, (values[index] || "").trim()])
  ));
}

function detectFileType(filename) {
  const name = filename.toLowerCase().replace(/\.csv$/, "").replace(/[^a-z0-9]+/g, "_");
  if (name.includes("order_items") || name.includes("order_item")) return "order_items";
  if (name.includes("orders")) return "orders";
  if (name.includes("products")) return "products";
  if (name.includes("customers")) return "customers";
  if (name.includes("category_name_translation") || name.includes("translation")) return "translations";
  return null;
}

async function loadFiles(fileList) {
  const parsed = {};
  const unrecognized = [];
  for (const file of fileList) {
    const type = detectFileType(file.name);
    if (!type) {
      unrecognized.push(file.name);
      continue;
    }
    parsed[type] = parseCsv(await file.text());
  }

  if (unrecognized.length) {
    throw new Error(`Could not identify ${unrecognized.join(", ")}. Rename files to include orders, order_items, products, or customers.`);
  }

  const missing = Object.keys(requiredColumns).filter((type) => !parsed[type]);
  if (missing.length) {
    throw new Error(`Select all four required CSVs: ${missing.join(", ")} still ${missing.length === 1 ? "is" : "are"} missing.`);
  }

  for (const [type, columns] of Object.entries(requiredColumns)) {
    const headers = new Set(Object.keys(parsed[type][0] || {}));
    const absent = columns.filter((column) => !headers.has(column));
    if (absent.length) throw new Error(`${type}.csv is missing required columns: ${absent.join(", ")}.`);
  }
  if (parsed.translations && parsed.translations.some((row) =>
    !("product_category_name" in row) || !("product_category_name_english" in row)
  )) {
    throw new Error("The category translation CSV needs product_category_name and product_category_name_english columns.");
  }

  activeData = {
    orders: parsed.orders,
    items: parsed.order_items,
    products: parsed.products,
    customers: parsed.customers,
    translations: parsed.translations || []
  };
  elements.badge.classList.add("real-data");
  elements.badge.innerHTML = "<span></span> Your Olist data";
  document.getElementById("data-footnote").textContent =
    "Revenue sums item price; canceled and unavailable orders are excluded. Data is processed in this browser.";
  populateFilters();
  renderDashboard();
  showToast(`Loaded ${integer.format(activeData.orders.length)} orders and ${integer.format(activeData.items.length)} line items.`);
}

function cleanCategory(category, translations) {
  if (!category) return "Uncategorized";
  const translation = translations.get(category);
  return humanize(translation || category);
}

function humanize(value) {
  return value
    .replace(/_/g, " ")
    .replace(/\b\w/g, (letter) => letter.toUpperCase());
}

function buildRecords(data) {
  const validOrders = new Map(
    data.orders
      .filter((order) => !["canceled", "unavailable"].includes((order.order_status || "").toLowerCase()))
      .map((order) => [order.order_id, order])
  );
  const customers = new Map(data.customers.map((customer) => [customer.customer_id, customer]));
  const products = new Map(data.products.map((product) => [product.product_id, product]));
  const translations = new Map(data.translations.map((row) => [
    row.product_category_name,
    row.product_category_name_english
  ]));

  return data.items.flatMap((item) => {
    const order = validOrders.get(item.order_id);
    if (!order) return [];
    const purchaseTimestamp = order.order_purchase_timestamp || "";
    const timestamp = Date.parse(purchaseTimestamp);
    const price = Number(item.price);
    const freight = Number(item.freight_value);
    if (!Number.isFinite(timestamp) || !Number.isFinite(price)) return [];
    const customer = customers.get(order.customer_id);
    const product = products.get(item.product_id);
    const date = new Date(timestamp);
    const month = /^\d{4}-\d{2}/.test(purchaseTimestamp)
      ? purchaseTimestamp.slice(0, 7)
      : `${date.getUTCFullYear()}-${String(date.getUTCMonth() + 1).padStart(2, "0")}`;
    return [{
      orderId: item.order_id,
      timestamp,
      month,
      state: customer?.customer_state || "Unknown",
      category: cleanCategory(product?.product_category_name, translations),
      price,
      freight: Number.isFinite(freight) ? freight : 0
    }];
  });
}

function populateFilters() {
  const records = buildRecords(activeData);
  populateSelect(elements.date, ["all", ...new Set(records.map((record) => record.month).sort())], (value) => {
    if (value === "all") return "All available dates";
    const [year, month] = value.split("-");
    return new Intl.DateTimeFormat("en", { month: "short", year: "numeric", timeZone: "UTC" })
      .format(new Date(Date.UTC(Number(year), Number(month) - 1, 1)));
  });
  populateSelect(elements.state, ["all", ...[...new Set(records.map((record) => record.state))].sort()], (value) =>
    value === "all" ? "All states" : value
  );
  populateSelect(elements.category, ["all", ...[...new Set(records.map((record) => record.category))].sort()], (value) =>
    value === "all" ? "All categories" : value
  );
}

function populateSelect(select, values, label) {
  const previous = select.value || "all";
  select.replaceChildren(...values.map((value) => {
    const option = document.createElement("option");
    option.value = value;
    option.textContent = label(value);
    return option;
  }));
  select.value = values.includes(previous) ? previous : "all";
}

function renderDashboard() {
  const records = buildRecords(activeData);
  const date = elements.date.value;
  const state = elements.state.value;
  const category = elements.category.value;
  const includeFreight = elements.freight.checked;
  const filtered = records.filter((record) =>
    (date === "all" || record.month === date) &&
    (state === "all" || record.state === state) &&
    (category === "all" || record.category === category)
  );
  const amount = (record) => record.price + (includeFreight ? record.freight : 0);
  const revenue = filtered.reduce((sum, record) => sum + amount(record), 0);
  const orders = new Set(filtered.map((record) => record.orderId)).size;

  document.getElementById("kpi-revenue").textContent = brl.format(revenue);
  document.getElementById("kpi-orders").textContent = integer.format(orders);
  document.getElementById("kpi-aov").textContent = brl.format(orders ? revenue / orders : 0);
  document.getElementById("kpi-items").textContent = integer.format(filtered.length);
  document.getElementById("revenue-scope").textContent = includeFreight ? "items + freight" : "item value";
  document.getElementById("revenue-range").textContent = date === "all"
    ? "Monthly revenue across available dates"
    : `Revenue for ${elements.date.options[elements.date.selectedIndex].text}`;

  renderRevenueChart(filtered, amount);
  renderRankChart("product-chart", sumBy(filtered, "category", amount), "No product sales for these filters.");
  renderStateChart(sumBy(filtered, "state", amount));
}

function sumBy(records, key, amount) {
  const totals = new Map();
  records.forEach((record) => totals.set(record[key], (totals.get(record[key]) || 0) + amount(record)));
  return [...totals.entries()].sort((first, second) => second[1] - first[1]);
}

function renderRevenueChart(records, amount) {
  const container = document.getElementById("revenue-chart");
  const totals = new Map();
  records.forEach((record) => totals.set(record.month, (totals.get(record.month) || 0) + amount(record)));
  const entries = [...totals.entries()].sort(([first], [second]) => first.localeCompare(second));
  if (!entries.length) {
    container.innerHTML = '<div class="empty-chart">No revenue for these filters.</div>';
    return;
  }

  const width = 620;
  const height = 220;
  const left = 43;
  const right = 12;
  const top = 14;
  const bottom = 28;
  const chartWidth = width - left - right;
  const chartHeight = height - top - bottom;
  const max = Math.max(...entries.map((entry) => entry[1]), 1);
  const step = entries.length > 1 ? chartWidth / (entries.length - 1) : 0;
  const points = entries.map((entry, index) => ({
    x: entries.length > 1 ? left + index * step : left + chartWidth / 2,
    y: top + chartHeight - (entry[1] / max) * chartHeight,
    month: entry[0],
    value: entry[1]
  }));
  const linePoints = points.map((point) => `${point.x},${point.y}`).join(" ");
  const areaPoints = `${left},${top + chartHeight} ${linePoints} ${points.at(-1).x},${top + chartHeight}`;
  const grid = [0, 1, 2, 3].map((index) => {
    const y = top + (chartHeight / 3) * index;
    const value = max * (1 - index / 3);
    return `<line class="grid-line" x1="${left}" y1="${y}" x2="${width - right}" y2="${y}"></line><text class="axis-label" x="${left - 7}" y="${y + 3}" text-anchor="end">${escapeHtml(compactBrl.format(value))}</text>`;
  }).join("");
  const labelStep = Math.max(1, Math.ceil(entries.length / 6));
  const labels = points.map((point, index) => {
    if (index % labelStep !== 0 && index !== points.length - 1) return "";
    const [year, month] = point.month.split("-");
    const label = monthFormat.format(new Date(Date.UTC(Number(year), Number(month) - 1, 1)));
    return `<text class="axis-label" x="${point.x}" y="${height - 5}" text-anchor="middle">${escapeHtml(label)}</text>`;
  }).join("");
  const circles = points.map((point) => `<circle class="point" cx="${point.x}" cy="${point.y}" r="3.5"><title>${escapeHtml(`${monthFormat.format(new Date(`${point.month}-01T00:00:00Z`))}: ${brl.format(point.value)}`)}</title></circle>`).join("");
  container.innerHTML = `<svg viewBox="0 0 ${width} ${height}" preserveAspectRatio="none" aria-hidden="true"><defs><linearGradient id="areaFill" x1="0" x2="0" y1="0" y2="1"><stop offset="0%" stop-color="#6eaa82" stop-opacity=".2"></stop><stop offset="100%" stop-color="#6eaa82" stop-opacity=".015"></stop></linearGradient></defs>${grid}<polygon class="area" points="${areaPoints}"></polygon><polyline class="line" points="${linePoints}"></polyline>${circles}${labels}</svg>`;
}

function renderRankChart(containerId, entries, emptyMessage) {
  const container = document.getElementById(containerId);
  if (!entries.length) {
    container.innerHTML = `<div class="empty-chart">${escapeHtml(emptyMessage)}</div>`;
    return;
  }
  const top = entries.slice(0, 5);
  const max = top[0][1] || 1;
  container.innerHTML = top.map(([name, value]) => `
    <div class="rank-row" title="${escapeHtml(name)}: ${escapeHtml(brl.format(value))}">
      <span class="rank-name">${escapeHtml(name)}</span>
      <span class="rank-track"><span class="rank-fill" style="width:${Math.max(1, (value / max) * 100)}%"></span></span>
      <span class="rank-value">${escapeHtml(compactBrl.format(value))}</span>
    </div>
  `).join("");
}

function renderStateChart(entries) {
  const container = document.getElementById("state-chart");
  if (!entries.length) {
    container.innerHTML = '<div class="empty-chart">No state sales for these filters.</div>';
    return;
  }
  const top = entries.slice(0, 8);
  const max = top[0][1] || 1;
  container.innerHTML = top.map(([name, value], index) => `
    <div class="state-item" title="${escapeHtml(name)}: ${escapeHtml(brl.format(value))}">
      <span class="state-rank">${String(index + 1).padStart(2, "0")}</span>
      <div class="state-meta"><div class="state-name">${escapeHtml(name)}</div>
        <div class="state-track"><div class="state-fill" style="width:${Math.max(1, (value / max) * 100)}%"></div></div>
      </div>
      <span class="state-value">${escapeHtml(compactBrl.format(value))}</span>
    </div>
  `).join("");
}

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, (character) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;"
  })[character]);
}

function showToast(message, isError = false) {
  clearTimeout(toastTimer);
  elements.toast.textContent = message;
  elements.toast.classList.toggle("error", isError);
  elements.toast.classList.add("visible");
  toastTimer = setTimeout(() => elements.toast.classList.remove("visible"), 4500);
}

function resetFilters() {
  elements.date.value = "all";
  elements.state.value = "all";
  elements.category.value = "all";
  elements.freight.checked = false;
  renderDashboard();
}

[elements.date, elements.state, elements.category, elements.freight].forEach((control) =>
  control.addEventListener("change", renderDashboard)
);
document.getElementById("reset-filters").addEventListener("click", resetFilters);
elements.upload.addEventListener("change", async (event) => {
  const files = [...event.target.files];
  if (!files.length) return;
  try {
    await loadFiles(files);
  } catch (error) {
    showToast(error.message || "Could not load the selected CSV files.", true);
  } finally {
    elements.upload.value = "";
  }
});

populateFilters();
renderDashboard();
